./objects/main.o: STM32CubeMX\Target_1\STM32CubeMX\Src\main.c \
  STM32CubeMX\Target_1\STM32CubeMX\Inc\main.h \
  STM32CubeMX\Target_1\STM32CubeMX\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal.h \
  STM32CubeMX\Target_1\STM32CubeMX\Inc\stm32l4xx_hal_conf.h \
  STM32CubeMX\Target_1\STM32CubeMX\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_rcc.h \
  STM32CubeMX\Target_1\STM32CubeMX\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_def.h \
  STM32CubeMX\Target_1\STM32CubeMX\Drivers\CMSIS\Device\ST\STM32L4xx\Include\stm32l4xx.h \
  STM32CubeMX\Target_1\STM32CubeMX\Drivers\CMSIS\Device\ST\STM32L4xx\Include\stm32l476xx.h \
  C:\Users\ooc26\AppData\Local\Arm\Packs\ARM\CMSIS\6.1.0\CMSIS\Core\Include\core_cm4.h \
  STM32CubeMX\Target_1\STM32CubeMX\Drivers\CMSIS\Device\ST\STM32L4xx\Include\system_stm32l4xx.h \
  STM32CubeMX\Target_1\STM32CubeMX\Drivers\STM32L4xx_HAL_Driver\Inc\Legacy\stm32_hal_legacy.h \
  STM32CubeMX\Target_1\STM32CubeMX\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_rcc_ex.h \
  STM32CubeMX\Target_1\STM32CubeMX\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_gpio.h \
  STM32CubeMX\Target_1\STM32CubeMX\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_gpio_ex.h \
  STM32CubeMX\Target_1\STM32CubeMX\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_dma.h \
  STM32CubeMX\Target_1\STM32CubeMX\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_cortex.h \
  STM32CubeMX\Target_1\STM32CubeMX\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_exti.h \
  STM32CubeMX\Target_1\STM32CubeMX\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_flash.h \
  STM32CubeMX\Target_1\STM32CubeMX\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_flash_ex.h \
  STM32CubeMX\Target_1\STM32CubeMX\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_flash_ramfunc.h \
  STM32CubeMX\Target_1\STM32CubeMX\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_pwr.h \
  STM32CubeMX\Target_1\STM32CubeMX\Drivers\STM32L4xx_HAL_Driver\Inc\stm32l4xx_hal_pwr_ex.h
